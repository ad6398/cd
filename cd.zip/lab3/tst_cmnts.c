#include<stdio.h>
int main(){
	//this is 1st single line comment 
	int a=5;
	
	

	printf("%d\n",a);
	//this is the second singleline comment;
}

