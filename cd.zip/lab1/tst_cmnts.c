#include<stdio.h>
int main(){
	//this is 1st single line comment containing multiline start charater/*
	int a=5;;
	/*this is a multiline comment of two lines containing having single line comment
	  character // but even then it is recognized properly*/
	printf("%d\n",a);
	//this is the second singleline comment;
}

