#include<stdio.h>
int main()
{
	int a=2;
	int b=a*2+3;
	int c=(a+b)%5;
}
