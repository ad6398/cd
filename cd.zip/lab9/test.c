#include<stdio.h>
int main(){
    char c=getchar();
    printf("%d",c);

}